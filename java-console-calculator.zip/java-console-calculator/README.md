# Java Console Calculator

## Overview

This is a basic Java console calculator that performs the following operations:

- Addition
- Subtraction
- Multiplication
- Division (with divide-by-zero handling)

## Features

- Uses Scanner for input.
- Loops until the user chooses to exit.
- Structured with individual methods for each operation.

## How to Run

1. Install JDK (Java Development Kit)
2. Compile the code:
   ```
   javac Calculator.java
   ```
3. Run the program:
   ```
   java Calculator
   ```

## Key Concepts

- Java Syntax
- Conditionals
- Loops (`while`)
- Methods
- Input/Output (`Scanner`)
- Exception handling (division by zero)